Map is for public use not for resell, if you would like a copy of the raw file, contact me through email @ renegadegaming@shaw.ca
Thank You & Enjoy the Free Map..